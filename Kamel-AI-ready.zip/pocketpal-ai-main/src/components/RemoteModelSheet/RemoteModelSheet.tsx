import React, {
  useState,
  useContext,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from 'react';
import {Alert, Keyboard, TouchableOpacity, View} from 'react-native';
import {
  Text,
  Button,
  TextInput as PaperTextInput,
  Chip,
  RadioButton,
  ActivityIndicator,
  Icon,
} from 'react-native-paper';
import {Dropdown} from '../ui';
import {observer} from 'mobx-react';
import debounce from 'lodash/debounce';
import {useCameraPermission} from 'react-native-vision-camera';

import {ServerQRScanner, Sheet, TextInput} from '..';
import {useTheme} from '../../hooks';
import {routerStore, serverStore} from '../../store';
import {L10nContext} from '../../utils';
import {isLocalHost} from '../../utils/network';
import {parseTimeoutMs} from '../../utils/timeout';
import {
  SERVER_TYPE_DROPDOWN_OPTIONS,
  ServerType,
  seedServerType,
  toServerType,
} from '../../utils/serverTypes';
import {RemoteModelInfo, ServerConfig} from '../../utils/types';
import {fetchModelsWithHeaders} from '../../api/openai';
import {detectServerType} from '../../api/servers/detect';
import {deriveListCaps} from '../../api/servers';
import {profileFor} from '../../api/servers';
import {t} from '../../locales';

import {createStyles} from './styles';
import {RouterModelRows} from './RouterModelRows';
import {ChatIcon, EyeIcon, EyeOffIcon} from '../../assets/icons';

interface RemoteModelSheetProps {
  isVisible: boolean;
  onDismiss: () => void;
  onModelAdded?: () => void;
}

export const RemoteModelSheet: React.FC<RemoteModelSheetProps> = observer(
  ({isVisible, onDismiss, onModelAdded}) => {
    const theme = useTheme();
    const l10n = useContext(L10nContext);
    const styles = createStyles(theme);

    // Connection
    const [url, setUrl] = useState('');
    const [serverName, setServerName] = useState('');
    const [apiKey, setApiKey] = useState('');
    const [timeoutSeconds, setTimeoutSeconds] = useState('');
    const [serverType, setServerType] = useState<ServerType>('unknown');
    const [secureTextEntry, setSecureTextEntry] = useState(true);

    // Auto-probe
    const [isProbing, setIsProbing] = useState(false);
    const [probeResult, setProbeResult] = useState<{
      ok: boolean;
      error?: string;
    } | null>(null);

    // Available models
    const [availableModels, setAvailableModels] = useState<RemoteModelInfo[]>(
      [],
    );
    const [selectedModelId, setSelectedModelId] = useState<string | null>(null);

    // Known server selection
    const [selectedServerId, setSelectedServerId] = useState<string | null>(
      null,
    );

    // Saving
    const [isSaving, setIsSaving] = useState(false);

    // Errors
    const [urlError, setUrlError] = useState('');

    const [isScannerOpen, setIsScannerOpen] = useState(false);
    const {hasPermission, requestPermission} = useCameraPermission();

    // Keep apiKey in a ref so debounced function reads current value
    const apiKeyRef = useRef(apiKey);
    useEffect(() => {
      apiKeyRef.current = apiKey;
    }, [apiKey]);

    const timeoutSecondsRef = useRef(timeoutSeconds);
    useEffect(() => {
      timeoutSecondsRef.current = timeoutSeconds;
    }, [timeoutSeconds]);

    // Reset all state when sheet reopens
    useEffect(() => {
      if (isVisible) {
        setUrl('');
        setServerName('');
        setApiKey('');
        setTimeoutSeconds('');
        timeoutSecondsRef.current = '';
        setServerType('unknown');
        setSecureTextEntry(true);
        setIsProbing(false);
        setProbeResult(null);
        setAvailableModels([]);
        setSelectedModelId(null);
        setSelectedServerId(null);
        setIsSaving(false);
        setUrlError('');
        setIsScannerOpen(false);
      }
    }, [isVisible]);

    const probeServer = useCallback(
      async (probeUrl: string) => {
        const trimmedUrl = probeUrl.trim();
        if (!trimmedUrl) {
          return;
        }
        try {
          // Validate URL format — throws on invalid
          const parsed = new URL(trimmedUrl);
          if (!parsed.hostname) {
            throw new Error('No hostname');
          }
        } catch {
          setUrlError(l10n.settings.serverUrlInvalid);
          return;
        }
        setUrlError('');
        setIsProbing(true);
        setProbeResult(null);
        try {
          const key = apiKeyRef.current.trim() || undefined;
          const timeoutMs = parseTimeoutMs(timeoutSecondsRef.current);
          const {models, headers} = await fetchModelsWithHeaders(
            trimmedUrl,
            key,
            timeoutMs,
          );
          setProbeResult({ok: true});
          setAvailableModels(models);
          if (models.length === 1) {
            setSelectedModelId(models[0].id);
          }
          const detected = await detectServerType(trimmedUrl, models, headers);
          setServerType(seedServerType(detected, trimmedUrl));
          setServerName(prev => {
            if (prev) {
              return prev;
            }
            if (detected) {
              return detected;
            }
            try {
              return new URL(trimmedUrl).hostname;
            } catch {
              return '';
            }
          });
        } catch (error: any) {
          setProbeResult({ok: false, error: error.message});
        } finally {
          setIsProbing(false);
        }
      },
      [l10n],
    );

    const debouncedProbe = useMemo(
      () => debounce(probeServer, 800),
      [probeServer],
    );

    // Trigger probe on url change (only when not using a known server chip)
    useEffect(() => {
      if (!selectedServerId) {
        debouncedProbe(url);
      }
      return () => {
        debouncedProbe.cancel();
      };
    }, [url, debouncedProbe, selectedServerId]);

    const handleDismiss = useCallback(() => {
      setIsScannerOpen(false);
      onDismiss();
    }, [onDismiss]);

    const handleScanPress = useCallback(async () => {
      let granted = hasPermission;
      if (!granted) {
        try {
          granted = await requestPermission();
        } catch {
          granted = false;
        }
      }
      if (!granted) {
        Alert.alert(
          l10n.camera.permissionTitle,
          l10n.settings.scanQrPermissionMessage,
        );
        return;
      }
      Keyboard.dismiss();
      setIsScannerOpen(true);
    }, [hasPermission, requestPermission, l10n]);

    const handleScanned = useCallback((value: string) => {
      setUrl(value);
      setUrlError('');
      setIsScannerOpen(false);
    }, []);

    // Re-probe on apiKey blur
    const handleApiKeyBlur = useCallback(() => {
      if (url.trim() && !selectedServerId) {
        debouncedProbe(url);
      }
    }, [url, debouncedProbe, selectedServerId]);

    const showHttpWarning =
      url.startsWith('http://') && url.length > 7 && !isLocalHost(url);

    const toggleSecureEntry = () => {
      setSecureTextEntry(!secureTextEntry);
    };

    // Check if a model is already added for the given server
    const isModelAlreadyAdded = useCallback(
      (servId: string, modelId: string) => {
        return serverStore.userSelectedModels.some(
          m => m.serverId === servId && m.remoteModelId === modelId,
        );
      },
      [],
    );

    // Known server chip press
    const handleServerChipPress = useCallback(async (server: ServerConfig) => {
      setSelectedServerId(server.id);
      setServerName(server.name);
      setUrl(server.url);
      setIsProbing(true);
      setProbeResult(null);
      setAvailableModels([]);
      setSelectedModelId(null);
      setUrlError('');
      setIsScannerOpen(false);
      try {
        const key = await serverStore.getApiKey(server.id);
        apiKeyRef.current = key || '';
        setApiKey(key || '');
        const result = await serverStore.fetchModelsForServer(server.id);
        if (!result.ok) {
          setProbeResult({ok: false, error: result.error});
          return;
        }
        const models = serverStore.serverModels.get(server.id) ?? [];
        const notYetAdded = serverStore.getModelsNotYetAdded(server.id);
        setAvailableModels(models);
        if (notYetAdded.length === 1) {
          setSelectedModelId(notYetAdded[0].id);
        }
        setProbeResult({ok: true});
      } catch (error: any) {
        setProbeResult({ok: false, error: error.message});
      } finally {
        setIsProbing(false);
      }
    }, []);

    const handleDeselectChip = useCallback(() => {
      setSelectedServerId(null);
      setUrl('');
      setServerName('');
      setApiKey('');
      apiKeyRef.current = '';
      setProbeResult(null);
      setAvailableModels([]);
      setSelectedModelId(null);
      setUrlError('');
    }, []);

    // Save / add model
    const handleAddModel = useCallback(async () => {
      if (!selectedModelId) {
        return;
      }
      setIsSaving(true);
      try {
        let serverId = selectedServerId;
        if (!serverId) {
          // Create new server
          serverId = serverStore.addServer({
            name: serverName.trim(),
            url: url.trim(),
            requestTimeoutMs: parseTimeoutMs(timeoutSeconds),
            serverType,
          });
          if (apiKey.trim()) {
            await serverStore.setApiKey(serverId, apiKey.trim());
          }
        }
        // Add model to user selections
        serverStore.addUserSelectedModel(serverId, selectedModelId);
        // Fetch models for this server so serverModels is populated
        await serverStore.fetchModelsForServer(serverId);
        onModelAdded?.();
        handleDismiss();
      } finally {
        setIsSaving(false);
      }
    }, [
      selectedModelId,
      selectedServerId,
      serverName,
      url,
      apiKey,
      timeoutSeconds,
      serverType,
      onModelAdded,
      handleDismiss,
    ]);

    const selectedServer = selectedServerId
      ? serverStore.servers.find(s => s.id === selectedServerId)
      : null;

    // The type in effect, which is not always the type this sheet detected:
    // pressing a known-server chip never calls setServerType, so on the very
    // routers this exists for the local state is still 'unknown'.
    const serverTypeInEffect = selectedServer?.serverType ?? serverType;

    const showPostConnection = probeResult?.ok === true;
    // Show API key + server name fields when probe attempted (success OR auth failure)
    // This lets users enter an API key after a 401, then retry
    const showServerFields =
      probeResult !== null && !isProbing && !selectedServerId;

    const isRouter =
      !!selectedServerId && routerStore.isRouter(selectedServerId);

    useEffect(() => {
      if (!isVisible || !isRouter || !selectedServerId) {
        return undefined;
      }
      routerStore.setPickerServer(selectedServerId);
      return () => routerStore.setPickerServer(null);
    }, [isVisible, isRouter, selectedServerId]);

    const renderVisionSlot = (model: RemoteModelInfo) => {
      if (profileFor(serverTypeInEffect).readListRow === undefined) {
        return null;
      }
      const listCaps = deriveListCaps(model, serverTypeInEffect);
      return (
        <View
          style={styles.modelVisionSlot}
          testID={`remote-model-row-vision-${model.id}`}
          accessible={true}
          accessibilityLabel={`${l10n.models.modelCard.labels.vision}: ${
            listCaps.supportsVision === true
              ? l10n.models.modelCard.labels.visionSupported
              : listCaps.supportsVision === false
                ? l10n.models.modelCard.labels.visionNotSupported
                : l10n.models.modelCard.labels.visionUnknown
          }`}>
          {listCaps.supportsVision === true ? (
            <EyeIcon
              width={16}
              height={16}
              stroke={theme.colors.iconModelTypeVision}
            />
          ) : listCaps.supportsVision === false ? (
            <ChatIcon
              width={16}
              height={16}
              stroke={theme.colors.iconModelTypeText}
            />
          ) : (
            <Text style={styles.modelVisionUnknown}>—</Text>
          )}
        </View>
      );
    };

    return (
      <Sheet
        isVisible={isVisible}
        onClose={handleDismiss}
        title={l10n.settings.addRemoteModel}
        snapPoints={['80%']}>
        <Sheet.ScrollView contentContainerStyle={styles.container}>
          {/* Privacy Notice */}
          {!serverStore.privacyNoticeAcknowledged && (
            <View style={styles.privacyContainer}>
              <Icon
                source="alert-outline"
                size={18}
                color={theme.colors.onTertiaryContainer}
              />
              <Text style={styles.privacyText}>
                {l10n.settings.remotePrivacyNotice}
              </Text>
              <TouchableOpacity
                testID="privacy-notice-dismiss"
                style={styles.privacyDismiss}
                onPress={() => serverStore.acknowledgePrivacyNotice()}>
                <Icon
                  source="close"
                  size={18}
                  color={theme.colors.onTertiaryContainer}
                />
              </TouchableOpacity>
            </View>
          )}

          {/* Known Server Chips */}
          {serverStore.servers.length > 0 && (
            <View style={styles.chipsSection}>
              <Text style={styles.chipsSectionLabel}>
                {l10n.settings.yourServers}
              </Text>
              <View style={styles.chipsRow}>
                {serverStore.servers.map(server => (
                  <Chip
                    key={server.id}
                    testID={`server-chip-${server.id}`}
                    selected={selectedServerId === server.id}
                    onPress={() => {
                      if (selectedServerId === server.id) {
                        handleDeselectChip();
                      } else {
                        handleServerChipPress(server);
                      }
                    }}>
                    {server.name}
                  </Chip>
                ))}
              </View>

              {/* Divider */}
              {!selectedServerId && (
                <View style={styles.dividerRow}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>
                    {l10n.settings.orConnectNewServer}
                  </Text>
                  <View style={styles.dividerLine} />
                </View>
              )}
            </View>
          )}

          {/* Chip server info when selected */}
          {selectedServer && probeResult?.ok && (
            <View style={styles.chipServerInfo}>
              <Text style={styles.chipServerName}>{selectedServer.name}</Text>
              <Text style={styles.chipServerUrl}>{selectedServer.url}</Text>
            </View>
          )}

          {/* Chip offline error */}
          {selectedServerId && probeResult?.ok === false && (
            <View style={styles.chipErrorContainer}>
              <Text style={styles.errorText}>
                {t(l10n.settings.connectionFailed, {
                  error: probeResult.error || 'Unknown',
                })}
              </Text>
              <View style={styles.chipErrorActions}>
                <Button
                  compact
                  mode="text"
                  onPress={() =>
                    selectedServer && handleServerChipPress(selectedServer)
                  }>
                  {l10n.settings.retryConnection}
                </Button>
                <Button compact mode="text" onPress={handleDeselectChip}>
                  {l10n.settings.enterUrlManually}
                </Button>
              </View>
            </View>
          )}

          {/* URL Input - only show when not using a known server chip */}
          {!selectedServerId && (
            <>
              {isScannerOpen && (
                <ServerQRScanner
                  onScanned={handleScanned}
                  onClose={() => setIsScannerOpen(false)}
                />
              )}
              <View style={styles.inputSpacing}>
                <TextInput
                  testID="remote-url-input"
                  label={l10n.settings.serverUrl}
                  value={url}
                  onChangeText={text => {
                    setUrl(text);
                    if (urlError) {
                      setUrlError('');
                    }
                  }}
                  placeholder={l10n.settings.serverUrlPlaceholder}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="url"
                  error={!!urlError}
                  right={
                    <PaperTextInput.Icon
                      testID="remote-url-scan"
                      icon="qrcode-scan"
                      accessibilityLabel={l10n.settings.scanServerQr}
                      forceTextInputFocus={false}
                      onPress={handleScanPress}
                    />
                  }
                />
                {urlError ? (
                  <Text style={styles.errorText}>{urlError}</Text>
                ) : null}
              </View>

              {/* Probe status */}
              {isProbing && (
                <View style={styles.probeStatusContainer}>
                  <ActivityIndicator size="small" />
                  <Text
                    style={[
                      styles.probeStatusText,
                      {color: theme.colors.onSurfaceVariant},
                    ]}>
                    {l10n.settings.connecting}
                  </Text>
                </View>
              )}

              {probeResult && !isProbing && (
                <View style={styles.probeStatusContainer}>
                  <Icon
                    source={
                      probeResult.ok
                        ? 'check-circle-outline'
                        : 'alert-circle-outline'
                    }
                    size={16}
                    color={
                      probeResult.ok ? theme.colors.primary : theme.colors.error
                    }
                  />
                  <Text
                    style={[
                      styles.probeStatusText,
                      probeResult.ok
                        ? styles.probeSuccessText
                        : styles.probeErrorText,
                    ]}>
                    {probeResult.ok
                      ? l10n.settings.connected
                      : t(l10n.settings.connectionFailed, {
                          error: probeResult.error || 'Unknown',
                        })}
                  </Text>
                </View>
              )}

              {/* HTTP Warning */}
              {showHttpWarning && (
                <View style={styles.warningContainer}>
                  <Text style={styles.warningText}>
                    {l10n.settings.serverUrlHttpWarning}
                  </Text>
                </View>
              )}
            </>
          )}

          {/* Server name + API key — shown after probe attempt (success OR failure)
              so user can enter API key after 401 and retry */}
          {showServerFields && (
            <>
              <View style={styles.inputSpacing}>
                <TextInput
                  testID="remote-name-input"
                  label={l10n.settings.serverName}
                  value={serverName}
                  onChangeText={setServerName}
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputSpacing}>
                <TextInput
                  testID="remote-apikey-input"
                  label={l10n.settings.apiKey}
                  value={apiKey}
                  onChangeText={setApiKey}
                  placeholder={l10n.settings.apiKeyPlaceholder}
                  autoCapitalize="none"
                  autoCorrect={false}
                  spellCheck={false}
                  secureTextEntry={secureTextEntry}
                  onBlur={handleApiKeyBlur}
                  right={
                    <PaperTextInput.Icon
                      testID="remote-apikey-toggle"
                      icon={({color}) =>
                        secureTextEntry ? (
                          <EyeIcon width={24} height={24} stroke={color} />
                        ) : (
                          <EyeOffIcon width={24} height={24} stroke={color} />
                        )
                      }
                      onPress={toggleSecureEntry}
                    />
                  }
                />
                <Text style={styles.apiKeyDescription}>
                  {l10n.settings.apiKeyDescription}
                </Text>
              </View>

              <View style={styles.inputSpacing}>
                <TextInput
                  testID="remote-timeout-input"
                  label={l10n.settings.requestTimeout}
                  value={timeoutSeconds}
                  onChangeText={setTimeoutSeconds}
                  placeholder={l10n.settings.requestTimeoutPlaceholder}
                  keyboardType="numeric"
                />
                <Text style={styles.apiKeyDescription}>
                  {l10n.settings.requestTimeoutHelp}
                </Text>
              </View>

              <View style={styles.inputSpacing}>
                <Text>{l10n.settings.serverType}</Text>
                <Dropdown
                  testID="server-type-dropdown"
                  value={serverType}
                  options={SERVER_TYPE_DROPDOWN_OPTIONS}
                  onChange={value => setServerType(toServerType(value))}
                />
                <Text style={styles.apiKeyDescription}>
                  {l10n.settings.serverTypeHelp}
                </Text>
              </View>
            </>
          )}

          {showPostConnection && isRouter && selectedServerId && (
            <RouterModelRows
              serverId={selectedServerId}
              selectedModelId={selectedModelId}
              onSelect={setSelectedModelId}
              isAlreadyAdded={modelId =>
                isModelAlreadyAdded(selectedServerId, modelId)
              }
              supportsVision={model =>
                deriveListCaps(model, serverTypeInEffect).supportsVision ===
                true
              }
            />
          )}

          {/* Model Selection */}
          {showPostConnection && !isRouter && availableModels.length >= 1 && (
            <View style={styles.modelListSection}>
              <Text style={styles.modelListLabel}>
                {l10n.settings.selectModel}
              </Text>
              {availableModels.map(model => {
                const servId = selectedServerId || '';
                const alreadyAdded =
                  !!selectedServerId && isModelAlreadyAdded(servId, model.id);
                return (
                  <TouchableOpacity
                    key={model.id}
                    activeOpacity={alreadyAdded ? 1 : 0.6}
                    style={[
                      styles.modelRow,
                      alreadyAdded && styles.modelRowDisabled,
                    ]}
                    onPress={() => {
                      if (!alreadyAdded) {
                        setSelectedModelId(model.id);
                      }
                    }}>
                    <RadioButton
                      value={model.id}
                      status={
                        alreadyAdded
                          ? 'checked'
                          : selectedModelId === model.id
                            ? 'checked'
                            : 'unchecked'
                      }
                      onPress={() => {
                        if (!alreadyAdded) {
                          setSelectedModelId(model.id);
                        }
                      }}
                      disabled={alreadyAdded}
                      uncheckedColor={theme.colors.onSurfaceVariant}
                    />
                    <Text
                      style={styles.modelName}
                      numberOfLines={1}
                      ellipsizeMode="middle">
                      {model.id}
                    </Text>
                    {alreadyAdded && (
                      <Text style={styles.alreadyAddedText}>
                        {l10n.settings.alreadyAdded}
                      </Text>
                    )}
                    {renderVisionSlot(model)}
                  </TouchableOpacity>
                );
              })}
            </View>
          )}

          {/* No models available */}
          {showPostConnection && !isRouter && availableModels.length === 0 && (
            <Text style={styles.noModelsText}>
              {l10n.settings.noModelsAvailable}
            </Text>
          )}

          {/* Probing indicator for chip selection */}
          {selectedServerId && isProbing && (
            <View style={styles.probeStatusContainer}>
              <ActivityIndicator size="small" />
              <Text
                style={[
                  styles.probeStatusText,
                  {color: theme.colors.onSurfaceVariant},
                ]}>
                {l10n.settings.connecting}
              </Text>
            </View>
          )}
        </Sheet.ScrollView>
        <Sheet.Actions>
          <View style={styles.buttonsContainer}>
            <Button
              testID="add-model-button"
              mode="contained"
              onPress={handleAddModel}
              loading={isSaving}
              disabled={
                isSaving || !selectedModelId || availableModels.length === 0
              }
              style={styles.addButton}>
              {l10n.settings.addModel}
            </Button>
          </View>
        </Sheet.Actions>
      </Sheet>
    );
  },
);
