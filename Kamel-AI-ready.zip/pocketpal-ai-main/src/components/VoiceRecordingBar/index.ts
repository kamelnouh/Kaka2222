export {VoiceRecordingBar} from './VoiceRecordingBar';
