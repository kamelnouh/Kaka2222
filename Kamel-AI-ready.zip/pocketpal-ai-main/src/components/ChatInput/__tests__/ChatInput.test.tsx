import {fireEvent, waitFor} from '@testing-library/react-native';
import * as React from 'react';
import {ScrollView, Alert, StyleSheet, TextInput} from 'react-native';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {runInAction} from 'mobx';

import {user} from '../../../../jest/fixtures';
import {l10n} from '../../../locales';
import {UserContext} from '../../../utils';
import {ChatInput} from '../ChatInput';
import {render} from '../../../../jest/test-utils';
import {
  asrStore,
  palStore,
  chatSessionStore,
  modelStore,
  voiceModeStore,
} from '../../../store';
import ReactNativeHapticFeedback from 'react-native-haptic-feedback';

// Mock react-native-image-picker
jest.mock('react-native-image-picker', () => ({
  launchCamera: jest.fn(),
  launchImageLibrary: jest.fn(),
}));

jest.spyOn(Alert, 'alert');

const renderScrollable = () => <ScrollView />;

describe('input', () => {
  it('send button', () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            sendButtonVisibilityMode: 'editing',
            textInputProps: {value: 'text'},
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(textInput, 'text');
    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(button);
    expect(onSendPress).toHaveBeenCalledWith({text: 'text', type: 'text'});
    expect(textInput.props).toHaveProperty('value', 'text');
  });

  it('sends a text message', () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            renderScrollable,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(textInput, 'text');
    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(button);
    expect(onSendPress).toHaveBeenCalledWith({text: 'text', type: 'text'});
    expect(textInput.props).toHaveProperty('value', '');
  });

  describe('while a send waits for a stopped run to drain', () => {
    beforeEach(() => {
      runInAction(() => {
        modelStore.activeModelId = 'test-model-id';
      });
      chatSessionStore.isStopping = true;
    });

    afterEach(() => {
      chatSessionStore.isStopping = false;
    });

    it('disables Send, announced as disabled, and keeps the typed text', () => {
      const onSendPress = jest.fn();
      const {getByPlaceholderText, getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              renderScrollable,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );
      const textInput = getByPlaceholderText(
        l10n.en.components.chatInput.inputPlaceholder,
      );
      fireEvent.changeText(textInput, 'second message');
      const button = getByLabelText(
        l10n.en.components.sendButton.accessibilityLabel,
      );

      expect(button.props.accessibilityState).toEqual(
        expect.objectContaining({disabled: true}),
      );
      fireEvent.press(button);
      expect(onSendPress).not.toHaveBeenCalled();
      expect(textInput.props.value).toBe('second message');
    });
  });

  it('sends a text message if onChangeText and value are provided', () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const value = 'value';
    const onChangeText = jest.fn(newValue => {
      rerender(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              renderScrollable,
              sendButtonVisibilityMode: 'editing',
              textInputProps: {onChangeText, value: newValue},
            }}
          />
        </UserContext.Provider>,
      );
    });
    const {getByPlaceholderText, getByLabelText, rerender} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            renderScrollable,
            sendButtonVisibilityMode: 'editing',
            textInputProps: {onChangeText, value},
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(textInput, 'text');
    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(button);
    expect(onSendPress).toHaveBeenCalledWith({text: 'text', type: 'text'});
    expect(textInput.props).toHaveProperty('value', 'text');
  });

  it('sends a text message if onChangeText is provided', () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const onChangeText = jest.fn();
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            renderScrollable,
            sendButtonVisibilityMode: 'editing',
            textInputProps: {onChangeText},
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(textInput, 'text');
    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(button);
    expect(onSendPress).toHaveBeenCalledWith({text: 'text', type: 'text'});
    expect(textInput.props).toHaveProperty('value', '');
  });

  it('sends a text message if value is provided', async () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const value = 'value';
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            renderScrollable,
            sendButtonVisibilityMode: 'editing',
            textInputProps: {value},
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    await waitFor(() => fireEvent.changeText(textInput, 'text')); // Wait for the input to update

    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    await waitFor(() => fireEvent.press(button)); // Wait for the press event to be processed

    expect(onSendPress).toHaveBeenCalledWith({text: value, type: 'text'});
    expect(textInput.props).toHaveProperty('value', value);
  });

  it('sends a text message if defaultValue is provided', () => {
    expect.assertions(2);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const defaultValue = 'defaultValue';
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            renderScrollable,
            sendButtonVisibilityMode: 'editing',
            textInputProps: {defaultValue},
          }}
        />
      </UserContext.Provider>,
    );
    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    const button = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(button);
    expect(onSendPress).toHaveBeenCalledWith({
      text: defaultValue,
      type: 'text',
    });
    expect(textInput.props).toHaveProperty('value', '');
  });

  it('shows stop button when isStopVisible is true', () => {
    expect.assertions(1);
    const onStopPress = jest.fn();
    const onSendPress = jest.fn();
    const {getByTestId} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            onStopPress,
            isStopVisible: true,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );
    const stopButton = getByTestId('stop-button');
    fireEvent.press(stopButton);
    expect(onStopPress).toHaveBeenCalledTimes(1);
  });

  it('shows plus button for image upload when showImageUpload is true', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            showImageUpload: true,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const plusButton = getByLabelText('Add image');
    expect(plusButton).toBeDefined();
  });

  it('does not show plus button when showImageUpload is false', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const {queryByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            showImageUpload: false,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const plusButton = queryByLabelText('Add image');
    expect(plusButton).toBeNull();
  });

  it('renders plus button correctly when vision is enabled', () => {
    expect.assertions(2);
    const onSendPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            showImageUpload: true,
            isVisionEnabled: true,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const plusButton = getByLabelText('Add image');
    expect(plusButton).toBeTruthy();
    expect(plusButton.props.accessibilityState.disabled).toBe(false);
  });

  it('shows pal selector button', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const onPalBtnPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            onPalBtnPress,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const palButton = getByLabelText('Select Pal');
    fireEvent.press(palButton);
    expect(onPalBtnPress).toHaveBeenCalledTimes(1);
  });

  it('lets the pal name and Think label shrink to fit beside the mic', async () => {
    const pal = await palStore.createPal({
      type: 'local',
      name: 'A Pal With A Name Too Long For The Composer Row',
      systemPrompt: 'Test pal',
      originalSystemPrompt: 'Test pal',
      isSystemPromptChanged: false,
      useAIPrompt: false,
      parameters: {},
      parameterSchema: [],
      source: 'local',
    });
    const originalActivePalId = Object.getOwnPropertyDescriptor(
      chatSessionStore,
      'activePalId',
    );
    const originalActiveModelId = modelStore.activeModelId;
    Object.defineProperty(chatSessionStore, 'activePalId', {
      get: jest.fn(() => pal.id),
      configurable: true,
    });
    runInAction(() => {
      modelStore.activeModelId = 'model-1';
    });

    try {
      const {getByTestId} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress: jest.fn(),
              sendButtonVisibilityMode: 'editing',
              showThinkingToggle: true,
            }}
          />
        </UserContext.Provider>,
      );

      const shrinkOf = (testID: string) =>
        StyleSheet.flatten(getByTestId(testID).props.style).flexShrink;
      expect(getByTestId('active-pal-name').props.numberOfLines).toBe(1);
      expect(getByTestId('thinking-toggle-label').props.numberOfLines).toBe(1);
      expect(shrinkOf('pal-selector')).toBe(1);
      expect(
        StyleSheet.flatten(getByTestId('pal-selector').props.style).minWidth,
      ).toBe(32);
      expect(shrinkOf('active-pal-name')).toBe(1);
      expect(shrinkOf('thinking-toggle')).toBeGreaterThan(0);
      expect(shrinkOf('thinking-toggle')).toBeLessThan(
        shrinkOf('pal-selector') / 100,
      );
      expect(shrinkOf('thinking-toggle-label')).toBe(1);
      expect(
        StyleSheet.flatten(getByTestId('thinking-toggle').props.style).minWidth,
      ).toBe(32);
    } finally {
      runInAction(() => {
        modelStore.activeModelId = originalActiveModelId;
      });
      if (originalActivePalId) {
        Object.defineProperty(
          chatSessionStore,
          'activePalId',
          originalActivePalId,
        );
      }
    }
  });

  it('shows video button for video pal type', async () => {
    expect.assertions(1);

    // Create a video pal and set it as active
    const videoPal = await palStore.createPal({
      type: 'local',
      name: 'Test Video Pal',
      systemPrompt: 'Test video pal',
      originalSystemPrompt: 'Test video pal',
      isSystemPromptChanged: false,
      useAIPrompt: false,
      parameters: {captureInterval: '3000'},
      parameterSchema: [
        {
          key: 'captureInterval',
          type: 'text',
          label: 'Capture Interval',
          required: true,
        },
      ],
      source: 'local',
      capabilities: {video: true},
    });

    // Mock the activePalId getter to return our video pal's ID
    const originalActivePalId = Object.getOwnPropertyDescriptor(
      chatSessionStore,
      'activePalId',
    );
    Object.defineProperty(chatSessionStore, 'activePalId', {
      get: jest.fn(() => videoPal.id),
      configurable: true,
    });

    const onSendPress = jest.fn();
    const onStartCamera = jest.fn();
    const {getByText, unmount} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            onStartCamera,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const videoButton = getByText('Start Camera');
    fireEvent.press(videoButton);
    expect(onStartCamera).toHaveBeenCalledTimes(1);

    // Cleanup: restore original activePalId mock
    unmount();
    if (originalActivePalId) {
      Object.defineProperty(
        chatSessionStore,
        'activePalId',
        originalActivePalId,
      );
    }
  });

  it('handles prompt text change for video pal', async () => {
    expect.assertions(1);

    // Create a video pal and set it as active
    const videoPal = await palStore.createPal({
      type: 'local',
      name: 'Test Video Pal',
      systemPrompt: 'Test video pal',
      originalSystemPrompt: 'Test video pal',
      isSystemPromptChanged: false,
      useAIPrompt: false,
      parameters: {captureInterval: '3000'},
      parameterSchema: [
        {
          key: 'captureInterval',
          type: 'text',
          label: 'Capture Interval',
          required: true,
        },
      ],
      source: 'local',
      capabilities: {video: true},
    });

    // Mock the activePalId getter to return our video pal's ID
    const originalActivePalId = Object.getOwnPropertyDescriptor(
      chatSessionStore,
      'activePalId',
    );
    Object.defineProperty(chatSessionStore, 'activePalId', {
      get: jest.fn(() => videoPal.id),
      configurable: true,
    });

    const onSendPress = jest.fn();
    const onPromptTextChange = jest.fn();
    const {getByPlaceholderText, unmount} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            onPromptTextChange,
            promptText: 'initial text',
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const textInput = getByPlaceholderText(l10n.en.video.promptPlaceholder);
    fireEvent.changeText(textInput, 'new text');
    expect(onPromptTextChange).toHaveBeenCalledWith('new text');

    // Cleanup: restore original activePalId mock
    unmount();
    if (originalActivePalId) {
      Object.defineProperty(
        chatSessionStore,
        'activePalId',
        originalActivePalId,
      );
    }
  });

  it('disables plus button when vision is not enabled', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            showImageUpload: true,
            isVisionEnabled: false,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const plusButton = getByLabelText('Add image');
    expect(plusButton.props.accessibilityState.disabled).toBe(true);
  });

  it('enables plus button when vision is enabled', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            showImageUpload: true,
            isVisionEnabled: true,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const plusButton = getByLabelText('Add image');
    expect(plusButton.props.accessibilityState.disabled).toBe(false);
  });

  it('shows send button with always visibility mode', () => {
    expect.assertions(1);
    const onSendPress = jest.fn();
    const {getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            sendButtonVisibilityMode: 'always',
          }}
        />
      </UserContext.Provider>,
    );

    const sendButton = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    expect(sendButton).toBeTruthy();
  });

  it('sends message with images when images are selected', () => {
    expect.assertions(1);
    // Set up an active model for the test
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
    });
    const onSendPress = jest.fn();
    const {getByPlaceholderText, getByLabelText} = render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress,
            sendButtonVisibilityMode: 'editing',
          }}
        />
      </UserContext.Provider>,
    );

    const textInput = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(textInput, 'test message');

    const sendButton = getByLabelText(
      l10n.en.components.sendButton.accessibilityLabel,
    );
    fireEvent.press(sendButton);

    expect(onSendPress).toHaveBeenCalledWith({
      text: 'test message',
      type: 'text',
    });
  });

  describe('Image Upload Functionality', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('opens image upload menu when plus button is pressed', () => {
      const onSendPress = jest.fn();
      const {getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const plusButton = getByLabelText('Add image');
      fireEvent.press(plusButton);

      // Menu should be visible after pressing plus button
      // This would need to be tested with the actual menu implementation
    });

    it('handles camera photo capture successfully', async () => {
      const mockResult = {
        assets: [{uri: 'file://test-photo.jpg'}],
      };
      (launchCamera as jest.Mock).mockResolvedValue(mockResult);

      const onSendPress = jest.fn();
      const {getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const plusButton = getByLabelText('Add image');
      fireEvent.press(plusButton);

      // Since testing the menu interaction is complex, let's test that the camera function works
      // by calling it directly (this tests the core functionality)
      expect(launchCamera).toHaveBeenCalledTimes(0); // Initially not called

      // The plus button should open the menu, but testing menu interaction is complex
      // For now, we'll test that the component renders correctly with image upload enabled
      expect(plusButton).toBeTruthy();
    });

    it('handles camera error gracefully', async () => {
      const mockError = new Error('Camera error');
      (launchCamera as jest.Mock).mockRejectedValue(mockError);

      const onSendPress = jest.fn();
      const {getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const plusButton = getByLabelText('Add image');
      fireEvent.press(plusButton);

      // Test that the component renders correctly even when camera errors are configured
      expect(plusButton).toBeTruthy();
      expect(launchCamera).toHaveBeenCalledTimes(0); // Not called until menu interaction
    });

    const renderWithImageUpload = () =>
      render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress: jest.fn(),
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

    const pressCameraMenuItem = async (
      screen: ReturnType<typeof renderWithImageUpload>,
    ) => {
      fireEvent.press(screen.getByLabelText('Add image'));
      fireEvent.press(await screen.findByText(l10n.en.camera.takePhoto));
    };

    it('adds the captured photo to the selection', async () => {
      (launchCamera as jest.Mock).mockResolvedValue({
        assets: [{uri: 'file://test-photo.jpg'}],
      });

      const screen = renderWithImageUpload();
      await pressCameraMenuItem(screen);

      expect(await screen.findByLabelText('Remove image 1')).toBeTruthy();
      expect(Alert.alert).not.toHaveBeenCalled();
    });

    it('alerts that no camera device was found when the camera is unavailable', async () => {
      (launchCamera as jest.Mock).mockResolvedValue({
        errorCode: 'camera_unavailable',
      });

      const screen = renderWithImageUpload();
      await pressCameraMenuItem(screen);

      await waitFor(() => {
        expect(Alert.alert).toHaveBeenCalledWith(
          l10n.en.camera.errorTitle,
          l10n.en.camera.noDevice,
        );
      });
      expect(launchCamera).toHaveBeenCalledTimes(1);
      expect(screen.queryByLabelText('Remove image 1')).toBeNull();
    });

    it('alerts with the generic camera error for other error codes', async () => {
      (launchCamera as jest.Mock).mockResolvedValue({
        errorCode: 'others',
        errorMessage: 'x',
      });

      const screen = renderWithImageUpload();
      await pressCameraMenuItem(screen);

      await waitFor(() => {
        expect(Alert.alert).toHaveBeenCalledWith(
          l10n.en.errors.cameraErrorTitle,
          l10n.en.errors.cameraErrorMessage,
        );
      });
    });

    it('stays silent when the camera is cancelled', async () => {
      (launchCamera as jest.Mock).mockResolvedValue({didCancel: true});

      const screen = renderWithImageUpload();
      await pressCameraMenuItem(screen);

      await waitFor(() => {
        expect(launchCamera).toHaveBeenCalledTimes(1);
      });
      expect(Alert.alert).not.toHaveBeenCalled();
    });

    it('closes the menu and re-enables auto-release after a camera error', async () => {
      (launchCamera as jest.Mock).mockResolvedValue({
        errorCode: 'camera_unavailable',
      });

      const screen = renderWithImageUpload();
      await pressCameraMenuItem(screen);

      await waitFor(() => {
        expect(modelStore.enableAutoRelease).toHaveBeenCalledWith(
          'camera-photo',
        );
      });
      expect(modelStore.disableAutoRelease).toHaveBeenCalledWith(
        'camera-photo',
      );
      await waitFor(
        () => {
          expect(screen.queryByText(l10n.en.camera.takePhoto)).toBeNull();
        },
        {timeout: 3000},
      );
    });

    it('handles image library selection successfully', async () => {
      const mockResult = {
        assets: [{uri: 'file://test-library-photo.jpg'}],
      };
      (launchImageLibrary as jest.Mock).mockResolvedValue(mockResult);

      const onSendPress = jest.fn();
      const {getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const plusButton = getByLabelText('Add image');
      fireEvent.press(plusButton);

      // Test that the component renders correctly with image library functionality
      expect(plusButton).toBeTruthy();
      expect(launchImageLibrary).toHaveBeenCalledTimes(0); // Not called until menu interaction
    });

    it('sends message with selected images', () => {
      // Set up an active model for the test
      runInAction(() => {
        modelStore.activeModelId = 'test-model-id';
      });
      const onSendPress = jest.fn();
      const defaultImages = ['file://image1.jpg', 'file://image2.jpg'];
      const {getByPlaceholderText, getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              showImageUpload: true,
              isVisionEnabled: true,
              sendButtonVisibilityMode: 'editing',
              defaultImages,
            }}
          />
        </UserContext.Provider>,
      );

      const textInput = getByPlaceholderText(
        l10n.en.components.chatInput.inputPlaceholder,
      );
      fireEvent.changeText(textInput, 'test with images');

      const sendButton = getByLabelText(
        l10n.en.components.sendButton.accessibilityLabel,
      );
      fireEvent.press(sendButton);

      expect(onSendPress).toHaveBeenCalledWith({
        text: 'test with images',
        type: 'text',
        imageUris: defaultImages,
      });
    });
  });

  describe('Edit Mode Functionality', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('shows edit bar when in edit mode', () => {
      runInAction(() => {
        chatSessionStore.isEditMode = true;
      });
      const onSendPress = jest.fn();
      const onCancelEdit = jest.fn();

      render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              onCancelEdit,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      expect(onCancelEdit).not.toHaveBeenCalled(); // Should not be called on render
    });

    it('calls onCancelEdit when cancel button is pressed', () => {
      const onSendPress = jest.fn();
      const onCancelEdit = jest.fn();

      // Start with edit mode enabled
      runInAction(() => {
        chatSessionStore.isEditMode = true;
      });

      const {getByTestId} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              onCancelEdit,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      // Find and press the cancel button in the edit bar
      const cancelButton = getByTestId('icon-button');
      fireEvent.press(cancelButton);

      expect(onCancelEdit).toHaveBeenCalledTimes(1);
    });
  });

  describe('Model Not Loaded Feedback', () => {
    it('shows warning and haptic feedback when trying to send without model', async () => {
      // Mock haptic feedback
      const hapticTriggerSpy = jest.spyOn(ReactNativeHapticFeedback, 'trigger');

      // Ensure no model is loaded
      runInAction(() => {
        modelStore.activeModelId = undefined;
        modelStore.context = undefined;
      });

      const onSendPress = jest.fn();

      const {getByPlaceholderText, getByLabelText, getByText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              renderScrollable,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const input = getByPlaceholderText(
        l10n.en.components.chatInput.inputPlaceholder,
      );
      fireEvent.changeText(input, 'Test message');

      const sendButton = getByLabelText(
        l10n.en.components.sendButton.accessibilityLabel,
      );
      fireEvent.press(sendButton);

      // Verify haptic feedback was triggered
      expect(hapticTriggerSpy).toHaveBeenCalledWith('notificationWarning', {
        enableVibrateFallback: true,
        ignoreAndroidSystemSettings: false,
      });

      // Verify helper text is displayed
      expect(getByText(l10n.en.chat.cannotSendWithoutModel)).toBeTruthy();

      // Verify onSendPress was NOT called
      expect(onSendPress).not.toHaveBeenCalled();

      hapticTriggerSpy.mockRestore();
    });

    it('allows sending when model is loaded', async () => {
      const onSendPress = jest.fn();

      // Ensure model is loaded
      runInAction(() => {
        modelStore.activeModelId = 'test-model';
        modelStore.context = {id: 'test-context'} as any;
      });

      const {getByPlaceholderText, getByLabelText} = render(
        <UserContext.Provider value={user}>
          <ChatInput
            {...{
              onSendPress,
              renderScrollable,
              sendButtonVisibilityMode: 'editing',
            }}
          />
        </UserContext.Provider>,
      );

      const input = getByPlaceholderText(
        l10n.en.components.chatInput.inputPlaceholder,
      );
      fireEvent.changeText(input, 'Test message');

      const sendButton = getByLabelText(
        l10n.en.components.sendButton.accessibilityLabel,
      );
      fireEvent.press(sendButton);

      // Verify onSendPress WAS called
      expect(onSendPress).toHaveBeenCalledWith({
        text: 'Test message',
        type: 'text',
        imageUris: undefined,
      });
    });
  });
});

describe('voice mode button', () => {
  const onVoicePress = jest.fn();
  const renderInput = (props: Record<string, unknown> = {}) =>
    render(
      <UserContext.Provider value={user}>
        <ChatInput
          {...{
            onSendPress: jest.fn(),
            sendButtonVisibilityMode: 'always',
            onVoicePress,
            ...props,
          }}
        />
      </UserContext.Provider>,
    );

  beforeEach(() => {
    jest.clearAllMocks();
    (voiceModeStore as any).reset();
    voiceModeStore.setUnlockOverride(true);
    runInAction(() => {
      modelStore.activeModelId = 'test-model-id';
      modelStore.deviceTier = 'high';
      modelStore.isContextLoading = false;
      chatSessionStore.isEditMode = false;
      asrStore.captureState = 'idle';
    });
  });

  it('shows the voice button while empty and Send once the user types', () => {
    const {getByTestId, queryByTestId, getByPlaceholderText} = renderInput();
    expect(getByTestId('voice-mode-button')).toBeTruthy();
    expect(queryByTestId('send-button')).toBeNull();

    const input = getByPlaceholderText(
      l10n.en.components.chatInput.inputPlaceholder,
    );
    fireEvent.changeText(input, 'h');
    expect(queryByTestId('voice-mode-button')).toBeNull();
    expect(getByTestId('send-button')).toBeTruthy();

    fireEvent.changeText(input, '');
    expect(getByTestId('voice-mode-button')).toBeTruthy();
  });

  it('opens voice mode on press, with a way to focus this composer', () => {
    const focus = TextInput.prototype.focus as jest.Mock;
    const {getByTestId} = renderInput();
    fireEvent.press(getByTestId('voice-mode-button'));
    expect(onVoicePress).toHaveBeenCalledTimes(1);

    focus.mockClear();
    onVoicePress.mock.calls[0][0]();
    expect(focus).toHaveBeenCalledTimes(1);
  });

  it('shows the lock badge when voice mode is locked', () => {
    voiceModeStore.setUnlockOverride(false);
    const {getByTestId} = renderInput();
    expect(getByTestId('voice-mode-lock')).toBeTruthy();
  });

  it.each([
    [
      'the device tier is below the gate',
      () => {
        modelStore.deviceTier = 'low';
      },
    ],
    [
      'dictation is recording',
      () => {
        asrStore.captureState = 'recording';
      },
    ],
    [
      'dictation is transcribing',
      () => {
        asrStore.captureState = 'transcribing';
      },
    ],
    [
      'a message is being edited',
      () => {
        chatSessionStore.isEditMode = true;
      },
    ],
  ])('shows no voice button when %s', (_case, arrange) => {
    runInAction(arrange);
    const {queryByTestId} = renderInput();
    expect(queryByTestId('voice-mode-button')).toBeNull();
  });

  it('shows no voice button while a reply runs', () => {
    const {queryByTestId} = renderInput({isStopVisible: true});
    expect(queryByTestId('voice-mode-button')).toBeNull();
  });

  it('shows no voice button with an image attached', () => {
    const {queryByTestId} = renderInput({defaultImages: ['file://a.jpg']});
    expect(queryByTestId('voice-mode-button')).toBeNull();
  });

  it('shows no voice button without a voice-mode handler', () => {
    const {queryByTestId} = renderInput({onVoicePress: undefined});
    expect(queryByTestId('voice-mode-button')).toBeNull();
  });
});
